import type { Pool } from "pg";
import type Redis from "ioredis";

export class NoHostAvailable extends Error {}

export class HostManager {
  constructor(private db: Pool, private redis: Redis) {}

  /** Reserva atômica: SKIP LOCKED impede que duas requisições peguem a mesma máquina. */
  async reserve(sessionId: string) {
    const { rows } = await this.db.query(
      `UPDATE hosts SET status='BUSY', current_session_id=$1
       WHERE id = (
         SELECT id FROM hosts
         WHERE status='ONLINE' AND current_session_id IS NULL
           AND last_heartbeat > now() - interval '15 seconds'
         ORDER BY last_heartbeat DESC
         FOR UPDATE SKIP LOCKED LIMIT 1)
       RETURNING *`, [sessionId]);
    if (!rows[0]) throw new NoHostAvailable();
    return rows[0];
  }

  async release(hostId: string) {
    await this.db.query(
      `UPDATE hosts SET status='ONLINE', current_session_id=NULL
       WHERE id=$1 AND status IN ('BUSY','STARTING')`, [hostId]);
  }

  async heartbeat(hostId: string) {
    await this.db.query(`UPDATE hosts SET last_heartbeat=now(),
      status = CASE WHEN status='OFFLINE' THEN 'ONLINE' ELSE status END WHERE id=$1`, [hostId]);
  }

  /** Rodar a cada ~5s: hosts sem heartbeat viram OFFLINE. */
  async sweepStale() {
    return this.db.query(`UPDATE hosts SET status='OFFLINE'
      WHERE status<>'OFFLINE' AND last_heartbeat < now() - interval '30 seconds'
      RETURNING id, current_session_id`);
  }
}
