import express from "express"; import { Pool } from "pg"; import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken"; import { WebSocketServer } from "ws"; import crypto from "crypto";
import http from "http"; import path from "path"; import { z } from "zod";
import { HostManager, NoHostAvailable } from "./services/HostManager.js";
import { AgentToApi } from "../../../packages/protocol/src/index.js";

// Fora do Docker o host "postgres" não resolve; troca por localhost.
const db = new Pool({ connectionString: (process.env.DATABASE_URL || "postgres://aliencloud:aliencloud@localhost:5432/aliencloud").replace("@postgres:", "@localhost:") });
const hm = new HostManager(db, null as any);
const SECRET = process.env.JWT_SECRET || "dev-secret";
const sha = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const agents = new Map<string, any>(); // hostId -> WebSocket

const app = express(); app.use(express.json());
app.use(express.static(path.resolve("apps/api/public")));
const wrap = (f: any) => (req: any, res: any) => f(req, res).catch((e: any) => { console.error(e); res.status(500).json({ error: "erro interno" }); });
const auth = (role?: string) => (req: any, res: any, next: any) => {
  try { req.user = jwt.verify((req.headers.authorization || "").slice(7), SECRET); } catch { return res.status(401).json({ error: "não autenticado" }); }
  if (role && req.user.role !== role) return res.status(403).json({ error: "sem permissão" }); next();
};
const audit = (actor: string, action: string, target?: string) => db.query("insert into audit_logs(actor_id,action,target) values($1,$2,$3)", [actor, action, target]);

// ---------- Auth ----------
app.post("/auth/register", wrap(async (req: any, res: any) => {
  const b = z.object({ email: z.string().email(), password: z.string().min(8), name: z.string().min(2).max(50) }).safeParse(req.body);
  if (!b.success) return res.status(400).json({ error: "dados inválidos (senha mínimo 8 caracteres)" });
  try {
    const u = (await db.query("insert into users(email,password_hash,display_name) values($1,$2,$3) returning id", [b.data.email.toLowerCase(), await bcrypt.hash(b.data.password, 12), b.data.name])).rows[0];
    await db.query("insert into wallets(user_id,balance_seconds) values($1,36000)", [u.id]); // 10h de teste
    res.json({ token: jwt.sign({ id: u.id, role: "user" }, SECRET, { expiresIn: "12h" }) });
  } catch { res.status(409).json({ error: "email já cadastrado" }); }
}));
app.post("/auth/login", wrap(async (req: any, res: any) => {
  const u = (await db.query("select u.*, r.name role from users u join roles r on r.id=u.role_id where email=$1", [String(req.body.email).toLowerCase()])).rows[0];
  if (!u || !(await bcrypt.compare(String(req.body.password), u.password_hash))) return res.status(401).json({ error: "credenciais inválidas" });
  if (u.blocked) return res.status(403).json({ error: "usuário bloqueado" });
  res.json({ token: jwt.sign({ id: u.id, role: u.role }, SECRET, { expiresIn: "12h" }) });
}));
app.post("/auth/logout", (_q, res) => res.json({ ok: true })); // JWT stateless: o cliente descarta o token
app.get("/me", auth(), wrap(async (req: any, res: any) => {
  res.json((await db.query("select u.id,u.email,u.display_name,w.balance_seconds from users u join wallets w on w.user_id=u.id where u.id=$1", [req.user.id])).rows[0]);
}));

// ---------- Jogos ----------
const PUB = "id,name,slug,description,category,cover_url,banner_url,status"; // nunca expõe executable_path
app.get("/games", auth(), wrap(async (_q: any, res: any) => res.json((await db.query(`select ${PUB} from games where status<>'hidden' order by name`)).rows)));
app.get("/games/:id", auth(), wrap(async (req: any, res: any) => res.json((await db.query(`select ${PUB} from games where id=$1`, [req.params.id])).rows[0] ?? {})));
app.post("/admin/games", auth("admin"), wrap(async (req: any, res: any) => {
  const g = z.object({ name: z.string(), slug: z.string().regex(/^[a-z0-9-]+$/), description: z.string().optional(), cover_url: z.string().optional(),
    banner_url: z.string().optional(), executable_path: z.string(), launch_arguments: z.string().default(""), working_directory: z.string().optional() }).safeParse(req.body);
  if (!g.success) return res.status(400).json({ error: g.error.flatten() });
  const d = g.data;
  const r = await db.query("insert into games(name,slug,description,cover_url,banner_url,executable_path,launch_arguments,working_directory) values($1,$2,$3,$4,$5,$6,$7,$8) returning id",
    [d.name, d.slug, d.description, d.cover_url, d.banner_url, d.executable_path, d.launch_arguments, d.working_directory]);
  await audit(req.user.id, "game.create", d.slug); res.json(r.rows[0]);
}));

// ---------- Sessões ----------
async function finish(id: string, hostId?: string) {
  const { rows } = await db.query(`update game_sessions set state='FINISHED', ended_at=now(),
    seconds_used=coalesce(extract(epoch from now()-started_at)::int,0)
    where id=$1 and state not in ('FINISHED','ERROR') and ($2::uuid is null or host_id=$2) returning user_id,host_id,seconds_used`, [id, hostId ?? null]);
  const s = rows[0]; if (!s) return;
  await db.query("update wallets set balance_seconds=greatest(0,balance_seconds-$2) where user_id=$1", [s.user_id, s.seconds_used]);
  await db.query("insert into transactions(user_id,type,seconds,session_id) values($1,'usage',$2,$3)", [s.user_id, -s.seconds_used, id]);
  if (s.host_id) await hm.release(s.host_id);
}
app.post("/games/:id/play", auth(), wrap(async (req: any, res: any) => {
  const g = (await db.query("select slug from games where id=$1 and status='active'", [req.params.id])).rows[0];
  if (!g) return res.status(404).json({ error: "jogo indisponível" });
  const w = (await db.query("select balance_seconds from wallets where user_id=$1", [req.user.id])).rows[0];
  if (!w || Number(w.balance_seconds) <= 0) return res.status(402).json({ error: "sem horas disponíveis" });
  let s: any; try { s = (await db.query("insert into game_sessions(user_id,game_id) values($1,$2) returning id", [req.user.id, req.params.id])).rows[0]; }
  catch { return res.status(409).json({ error: "você já tem uma sessão ativa" }); }
  let host: any;
  try {
    host = await hm.reserve(s.id);
    const ws = agents.get(host.id); if (!ws) throw new Error("agente desconectado");
    await db.query("update game_sessions set state='STARTING', host_id=$2, started_at=now() where id=$1", [s.id, host.id]);
    const ice = [{ urls: "stun:stun.l.google.com:19302" }, ...(process.env.TURN_SERVER ? [{ urls: process.env.TURN_SERVER, username: process.env.TURN_USERNAME, credential: process.env.TURN_PASSWORD }] : [])];
    ws.send(JSON.stringify({ type: "session.start", sessionId: s.id, gameSlug: g.slug, iceServers: ice }));
    res.json({ sessionId: s.id });
  } catch (e: any) {
    if (host) await hm.release(host.id);
    await db.query("update game_sessions set state='ERROR', error=$2 where id=$1", [s.id, e.message]);
    res.status(e instanceof NoHostAvailable ? 503 : 500).json({ error: e instanceof NoHostAvailable ? "nenhuma máquina disponível" : e.message });
  }
}));
app.get("/sessions/:id", auth(), wrap(async (req: any, res: any) => {
  const s = (await db.query("select id,state,started_at,ended_at,seconds_used,error from game_sessions where id=$1 and (user_id=$2 or $3='admin')", [req.params.id, req.user.id, req.user.role])).rows[0];
  s ? res.json(s) : res.status(404).json({ error: "não encontrada" });
}));
app.post("/sessions/:id/stop", auth(), wrap(async (req: any, res: any) => {
  const s = (await db.query("select id,host_id from game_sessions where id=$1 and (user_id=$2 or $3='admin') and state in ('STARTING','READY','PLAYING')", [req.params.id, req.user.id, req.user.role])).rows[0];
  if (!s) return res.status(404).json({ error: "sessão ativa não encontrada" });
  await db.query("update game_sessions set state='STOPPING' where id=$1", [s.id]);
  const ws = agents.get(s.host_id);
  ws ? ws.send(JSON.stringify({ type: "session.stop", sessionId: s.id })) : await finish(s.id);
  res.json({ ok: true });
}));
app.get("/wallet", auth(), wrap(async (req: any, res: any) => res.json((await db.query("select balance_seconds from wallets where user_id=$1", [req.user.id])).rows[0])));
app.get("/transactions", auth(), wrap(async (req: any, res: any) => res.json((await db.query("select type,seconds,created_at from transactions where user_id=$1 order by created_at desc limit 50", [req.user.id])).rows)));

// ---------- Hosts ----------
app.post("/hosts/register", wrap(async (req: any, res: any) => {
  if (req.headers["x-registration-token"] !== (process.env.HOST_REGISTRATION_TOKEN || "token-para-registrar-hosts")) return res.status(403).json({ error: "token inválido" });
  const token = crypto.randomBytes(32).toString("hex");
  const h = (await db.query("insert into hosts(name,auth_token_hash) values($1,$2) returning id", [String(req.body.name || "host").slice(0, 60), sha(token)])).rows[0];
  res.json({ id: h.id, token });
}));
app.get("/hosts", auth("admin"), wrap(async (_q: any, res: any) => res.json((await db.query("select id,name,status,gpu,cpu,last_heartbeat,current_session_id from hosts")).rows)));
app.get("/admin/hosts", auth("admin"), wrap(async (_q: any, res: any) => res.json((await db.query("select * from hosts")).rows.map(({ auth_token_hash, ...h }: any) => h))));
app.get("/admin/sessions", auth("admin"), wrap(async (_q: any, res: any) => res.json((await db.query("select * from game_sessions order by created_at desc limit 100")).rows)));
app.get("/admin/logs", auth("admin"), wrap(async (_q: any, res: any) => res.json((await db.query("select * from audit_logs order by id desc limit 100")).rows)));

// ---------- WebSocket dos Host Agents ----------
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/agent" });
wss.on("connection", async (ws, req) => {
  const q = new URL(req.url!, "http://x").searchParams; const hostId = q.get("hostId") || "";
  const h = (await db.query("select auth_token_hash from hosts where id::text=$1", [hostId]).catch(() => ({ rows: [] as any[] }))).rows[0];
  if (!h || h.auth_token_hash !== sha(q.get("token") || "")) return ws.close(4401);
  agents.set(hostId, ws);
  await db.query("update hosts set status=case when current_session_id is null then 'ONLINE' else status end, last_heartbeat=now() where id=$1", [hostId]);
  console.log("host conectado", hostId);
  ws.on("message", async (raw) => {
    const m = AgentToApi.safeParse(JSON.parse(raw.toString())); if (!m.success) return;
    const d = m.data;
    if (d.type === "host.heartbeat") await hm.heartbeat(hostId);
    if (d.type === "session.ready") await db.query("update game_sessions set state='READY' where id=$1 and host_id=$2 and state='STARTING'", [d.sessionId, hostId]);
    if (d.type === "session.ended") await finish(d.sessionId, hostId);
    if (d.type === "log") console.log(`[host ${hostId}] ${d.level}: ${d.message}`);
  });
  ws.on("close", async () => { agents.delete(hostId); await db.query("update hosts set status='OFFLINE' where id=$1", [hostId]); });
});
setInterval(() => hm.sweepStale().catch(() => {}), 10000);

// ---------- Seed ----------
async function seed() {
  if (!(await db.query("select 1 from users where email='admin@aliencloud.local'")).rows[0]) {
    const u = (await db.query("insert into users(email,password_hash,display_name,role_id) values('admin@aliencloud.local',$1,'Admin',2) returning id", [await bcrypt.hash("admin12345", 12)])).rows[0];
    await db.query("insert into wallets(user_id,balance_seconds) values($1,360000)", [u.id]);
  }
  if (!(await db.query("select 1 from games where slug='gta-v'")).rows[0])
    await db.query("insert into games(name,slug,description,category,executable_path,working_directory) values('GTA V','gta-v','Mundo aberto em Los Santos.','Ação','C:\\Games\\GTA V\\PlayGTAV.exe','C:\\Games\\GTA V')");
}
await seed();
server.listen(4000, () => console.log("AlienCloud API em http://localhost:4000"));
