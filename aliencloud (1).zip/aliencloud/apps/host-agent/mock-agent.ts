// Agente SIMULADO: valida o fluxo de controle. Não captura vídeo nem inicia jogo real.
import WebSocket from "ws";
const API = process.env.API_URL || "http://localhost:4000";
const r = await fetch(API + "/hosts/register", { method: "POST",
  headers: { "content-type": "application/json", "x-registration-token": process.env.HOST_REGISTRATION_TOKEN || "token-para-registrar-hosts" },
  body: JSON.stringify({ name: "PC Simulado" }) });
const { id, token } = await r.json() as any;
const ws = new WebSocket(API.replace("http", "ws") + `/agent?hostId=${id}&token=${token}`);
ws.on("open", () => { console.log("agente conectado:", id);
  setInterval(() => ws.send(JSON.stringify({ type: "host.heartbeat", cpu: 12, ramUsedMb: 4096 })), 5000); });
ws.on("message", (d) => {
  const m = JSON.parse(d.toString());
  if (m.type === "session.start") { console.log("iniciando jogo:", m.gameSlug);
    setTimeout(() => ws.send(JSON.stringify({ type: "session.ready", sessionId: m.sessionId })), 2000); }
  if (m.type === "session.stop") { console.log("encerrando jogo");
    ws.send(JSON.stringify({ type: "session.ended", sessionId: m.sessionId, reason: "stopped" })); }
});
