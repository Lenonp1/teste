CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE roles (id SERIAL PRIMARY KEY, name TEXT UNIQUE NOT NULL);
INSERT INTO roles(name) VALUES ('user'),('admin');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role_id INT NOT NULL REFERENCES roles(id) DEFAULT 1,
  blocked BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE games (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  category TEXT,
  cover_url TEXT,
  banner_url TEXT,
  executable_path TEXT NOT NULL,      -- somente admin altera
  launch_arguments TEXT NOT NULL DEFAULT '',
  working_directory TEXT,
  max_session_minutes INT NOT NULL DEFAULT 180,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','maintenance','hidden')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE hosts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  ip INET,
  status TEXT NOT NULL DEFAULT 'OFFLINE' CHECK (status IN ('OFFLINE','ONLINE','STARTING','BUSY','ERROR')),
  gpu TEXT, cpu TEXT, ram_mb INT,
  agent_version TEXT,
  auth_token_hash TEXT NOT NULL,
  max_sessions INT NOT NULL DEFAULT 1,
  last_heartbeat TIMESTAMPTZ,
  current_session_id UUID
);

CREATE TABLE game_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  game_id UUID NOT NULL REFERENCES games(id),
  host_id UUID REFERENCES hosts(id),
  state TEXT NOT NULL DEFAULT 'QUEUED'
    CHECK (state IN ('QUEUED','STARTING','READY','PLAYING','STOPPING','FINISHED','ERROR')),
  started_at TIMESTAMPTZ, ended_at TIMESTAMPTZ,
  seconds_used INT NOT NULL DEFAULT 0,
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE hosts ADD CONSTRAINT fk_host_session FOREIGN KEY (current_session_id) REFERENCES game_sessions(id);
-- Garantia extra no banco: um usuário só tem 1 sessão ativa
CREATE UNIQUE INDEX one_active_session_per_user ON game_sessions(user_id)
  WHERE state IN ('QUEUED','STARTING','READY','PLAYING','STOPPING');

CREATE TABLE wallets (
  user_id UUID PRIMARY KEY REFERENCES users(id),
  balance_seconds BIGINT NOT NULL DEFAULT 0 CHECK (balance_seconds >= 0)
);

CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  type TEXT NOT NULL CHECK (type IN ('purchase','usage','refund','adjustment')),
  seconds BIGINT NOT NULL,            -- positivo = crédito, negativo = consumo
  session_id UUID REFERENCES game_sessions(id),
  payment_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Nunca guardar dados de cartão: apenas referência do gateway
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  provider TEXT NOT NULL, provider_ref TEXT,
  method TEXT NOT NULL,               -- pix | card | ...
  amount_cents INT NOT NULL, currency TEXT NOT NULL DEFAULT 'BRL',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE audit_logs (
  id BIGSERIAL PRIMARY KEY,
  actor_id UUID, action TEXT NOT NULL, target TEXT, meta JSONB,
  ip INET, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
