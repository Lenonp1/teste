import { z } from "zod";

// ---------- Control plane: API <-> Host Agent (WebSocket autenticado) ----------
// O agente recebe apenas gameSlug. O executável vem da allowlist LOCAL do agente.
export const SessionState = z.enum(["QUEUED","STARTING","READY","PLAYING","STOPPING","FINISHED","ERROR"]);

export const ApiToAgent = z.discriminatedUnion("type", [
  z.object({ type: z.literal("session.start"), sessionId: z.string().uuid(), gameSlug: z.string().regex(/^[a-z0-9-]+$/),
             iceServers: z.array(z.object({ urls: z.string(), username: z.string().optional(), credential: z.string().optional() })) }),
  z.object({ type: z.literal("session.stop"), sessionId: z.string().uuid() }),
  z.object({ type: z.literal("signal"), sessionId: z.string().uuid(), payload: z.any() }),
]);

export const AgentToApi = z.discriminatedUnion("type", [
  z.object({ type: z.literal("host.heartbeat"), cpu: z.number(), gpu: z.number().optional(), ramUsedMb: z.number() }),
  z.object({ type: z.literal("session.ready"), sessionId: z.string().uuid() }),
  z.object({ type: z.literal("session.ended"), sessionId: z.string().uuid(), reason: z.enum(["stopped","crashed","timeout"]) }),
  z.object({ type: z.literal("stream.status"), sessionId: z.string().uuid(), fps: z.number(), bitrateKbps: z.number(), width: z.number(), height: z.number() }),
  z.object({ type: z.literal("signal"), sessionId: z.string().uuid(), payload: z.any() }),
  z.object({ type: z.literal("log"), level: z.enum(["info","warn","error"]), message: z.string().max(2000) }),
]);

// ---------- Data plane: Browser -> Host Agent (WebRTC DataChannel) ----------
// "input" = unreliable/unordered (maxRetransmits:0) p/ gamepad e mouse;
// "input-reliable" = ordered p/ teclas e botões do mouse.
export const KeyEvent = z.object({ t: z.literal("key"), code: z.string().max(32), down: z.boolean(), seq: z.number().int() });
export const MouseMove = z.object({ t: z.literal("mm"), dx: z.number().int(), dy: z.number().int(), seq: z.number().int() });
export const MouseButton = z.object({ t: z.literal("mb"), button: z.number().int().min(0).max(4), down: z.boolean() });
export const MouseWheel = z.object({ t: z.literal("mw"), dy: z.number().int() });

// Estado completo (XInput). Estado em vez de delta tolera perda de pacotes.
export const GamepadState = z.object({
  t: z.literal("gp"),
  pad: z.number().int().min(0).max(3),
  buttons: z.number().int().min(0).max(0xffff),
  lt: z.number().int().min(0).max(255), rt: z.number().int().min(0).max(255),
  lx: z.number().int().min(-32768).max(32767), ly: z.number().int().min(-32768).max(32767),
  rx: z.number().int().min(-32768).max(32767), ry: z.number().int().min(-32768).max(32767),
  seq: z.number().int(),
});

export const InputMessage = z.discriminatedUnion("t", [KeyEvent, MouseMove, MouseButton, MouseWheel, GamepadState]);
export type InputMessage = z.infer<typeof InputMessage>;

export const XINPUT = { UP:0x1, DOWN:0x2, LEFT:0x4, RIGHT:0x8, START:0x10, BACK:0x20, LS:0x40, RS:0x80,
                        LB:0x100, RB:0x200, A:0x1000, B:0x2000, X:0x4000, Y:0x8000 } as const;
// Gamepad API (standard mapping) -> bitmask; índices 6/7 (LT/RT) são analógicos
export const STANDARD_BUTTON_MAP = [XINPUT.A, XINPUT.B, XINPUT.X, XINPUT.Y, XINPUT.LB, XINPUT.RB, 0, 0,
                                    XINPUT.BACK, XINPUT.START, XINPUT.LS, XINPUT.RS, XINPUT.UP, XINPUT.DOWN, XINPUT.LEFT, XINPUT.RIGHT];
