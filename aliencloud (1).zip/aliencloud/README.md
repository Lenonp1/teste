# AlienCloud

Cloud gaming: control plane (API, DB, sessões) separado do data plane (WebRTC vídeo/áudio/input).

## Rodar a fundação
```bash
cp .env.example .env
docker compose -f docker/docker-compose.yml up postgres redis turn -d
```
As migrations em `database/migrations` rodam automaticamente na primeira subida do Postgres.

## Decisões de arquitetura
- **Agente com allowlist local**: a API envia só `gameSlug`; o agente resolve o executável na sua própria config. Mesmo que a API seja comprometida, não dá para mandar um `.exe` arbitrário. O agente usa `spawn` sem shell.
- **Reserva de host**: `UPDATE ... FOR UPDATE SKIP LOCKED` (ver `HostManager.ts`) + índice único de 1 sessão ativa por usuário.
- **Input**: estado completo de gamepad (XInput) em DataChannel não-confiável; teclas em canal confiável. Schema em `packages/protocol`.
- **Vídeo**: nunca passa pela API. Host -> WebRTC (via TURN se necessário) -> navegador. API só faz sinalização.

## Host Agent (Windows) — stack recomendada
- Runtime: **Go + Pion WebRTC** (binário único, roda como serviço Windows) ou Node + node-datachannel.
- Captura + encode: DXGI Desktop Duplication / Windows Graphics Capture + **NVENC/AMF/QuickSync (H.264)** via FFmpeg/GStreamer, entregue como RTP ao Pion. Áudio: WASAPI loopback -> Opus.
- Gamepad virtual: **ViGEmBus** (driver que emula Xbox 360). Teclado/mouse: `SendInput`.
- Instalação: instalar ViGEmBus, copiar `agent.config.json`, registrar serviço (`sc create` / NSSM).

## Roadmap
1. **Fase 1 (MVP)**: auth, GET /games, POST /games/:id/play, HostManager, agente (spawn + kill + heartbeat), sinalização WebRTC, /play/[sessionId] com teclado/mouse.
2. Fase 2: controles virtuais + Gamepad API, fullscreen, pointer lock, reconexão.
3. Fase 3: admin, carteira/horas, PaymentService, filas, métricas.

## Avisos
- **Licenças**: rodar jogos comerciais (GTA V etc.) para vários usuários pagantes normalmente viola os termos da Rockstar/Steam. Use jogos próprios, com licença de cloud gaming, ou uso pessoal.
- Latência real depende de GPU com encoder de hardware, upload do host e TURN bem posicionado.
